package net.xmas.candycanes;

import net.minecraft.network.packet.s2c.play.PlayerListHeaderS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.*;

/** Tab list header, player names (icon + bold team colour) and ordering. */
public final class TabList {
    /** Change this to change the flashing title. */
    private static final String TITLE = "reindeer games 2026";
    private static final Formatting[] CYCLE = {Formatting.RED, Formatting.GREEN, Formatting.WHITE};

    private static final Map<UUID, Integer> LAST_ORDER = new HashMap<>();

    private TabList() {}

    /** Tab list entry for a player, or null to let vanilla handle players without a Christmas team. */
    public static Text nameText(ServerPlayerEntity p) {
        CandyCanes.XmasTeam x = CandyCanes.teamOf(p);
        if (x == null) return null;
        return Text.empty()
                .append(Icons.team(x))
                .append(Text.literal(" "))
                .append(Text.literal(p.getNameForScoreboard()).formatted(x.color(), Formatting.BOLD));
    }

    /**
     * Higher number = higher in the list. Teams are kept together in the order of CandyCanes.TEAMS,
     * and inside each team the player with the most canes is on top.
     */
    public static int order(ServerPlayerEntity p) {
        CandyCanes.XmasTeam x = CandyCanes.teamOf(p);
        int teamIndex = -1;
        if (x != null) teamIndex = CandyCanes.TEAMS.indexOf(x);

        long base = teamIndex < 0 ? 0 : (long) (CandyCanes.TEAMS.size() - teamIndex) * 100_000_000L;
        long canes = Math.min(CaneData.get().getCanes(p.getUuid()), 99_999_999L);
        int value = (int) (base + canes);
        return CaneData.get().tabOrderInverted ? -value : value;
    }

    /** Push new names + order to everyone's tab list for these players. */
    public static void refresh(MinecraftServer server, Collection<ServerPlayerEntity> players) {
        if (players.isEmpty()) return;
        for (ServerPlayerEntity p : players) LAST_ORDER.put(p.getUuid(), order(p));
        server.getPlayerManager().sendToAll(new PlayerListS2CPacket(
                EnumSet.of(PlayerListS2CPacket.Action.UPDATE_DISPLAY_NAME, PlayerListS2CPacket.Action.UPDATE_LIST_ORDER),
                players));
    }

    public static void tick(MinecraftServer server, int tick) {
        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();

        // Flashing header, every 5 ticks
        if (tick % 5 == 0) {
            int phase = (tick / 5) % CYCLE.length;
            MutableText title = Text.empty();
            for (int i = 0; i < TITLE.length(); i++) {
                title.append(Text.literal(String.valueOf(TITLE.charAt(i)))
                        .formatted(CYCLE[(i + phase) % CYCLE.length], Formatting.BOLD));
            }
            Text header = Text.literal("\n").append(title).append(Text.literal("\n"));
            PlayerListHeaderS2CPacket packet = new PlayerListHeaderS2CPacket(header, Text.empty());
            for (ServerPlayerEntity p : players) p.networkHandler.sendPacket(packet);
        }

        // Re-sort when somebody's canes changed, once per second
        if (tick % 20 == 0) {
            List<ServerPlayerEntity> changed = new ArrayList<>();
            for (ServerPlayerEntity p : players) {
                Integer last = LAST_ORDER.get(p.getUuid());
                if (last == null || last != order(p)) changed.add(p);
            }
            if (!changed.isEmpty()) {
                for (ServerPlayerEntity p : changed) LAST_ORDER.put(p.getUuid(), order(p));
                server.getPlayerManager().sendToAll(new PlayerListS2CPacket(
                        EnumSet.of(PlayerListS2CPacket.Action.UPDATE_LIST_ORDER), changed));
            }
        }
    }
}
