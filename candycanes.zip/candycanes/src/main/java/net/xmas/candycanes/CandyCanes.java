package net.xmas.candycanes;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class CandyCanes implements ModInitializer {
    public static final String MOD_ID = "candycanes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** The 5 Christmas teams. glyph = icon character in the resource pack font. */
    public record XmasTeam(String id, String display, Formatting color, int glyph) {
        public String scoreboardName() { return "xmas_" + id; }
    }

    public static final List<XmasTeam> TEAMS = List.of(
            new XmasTeam("santa",    "Santa Hat",      Formatting.RED,   0xE001),
            new XmasTeam("tree",     "Christmas Tree", Formatting.GREEN, 0xE002),
            new XmasTeam("snowman",  "Snowman",        Formatting.WHITE, 0xE003),
            new XmasTeam("gift",     "Gift",           Formatting.GOLD,  0xE004),
            new XmasTeam("ornament", "Ornament",       Formatting.AQUA,  0xE005)
    );

    private int tickCounter = 0;

    @Override
    public void onInitialize() {
        CaneData.load();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                CaneCommands.register(dispatcher));

        Freeze.register();

        ServerLifecycleEvents.SERVER_STARTED.register(CandyCanes::setupTeams);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> CaneData.save());

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            CaneData.get().entry(p.getUuid(), p.getNameForScoreboard());
            CaneData.save();
        });

        // Deaths: candy-cane burst + canes for the killer
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayerEntity victim)) return;

            deathBurst(victim);

            if (!(source.getAttacker() instanceof ServerPlayerEntity killer)) return;
            if (killer == victim) return;
            if (killer.isTeammate(victim)) return; // no cane farming on teammates

            CaneData data = CaneData.get();
            int reward = data.getWorth(victim.getUuid());
            data.entry(killer.getUuid(), killer.getNameForScoreboard()).canes += reward;
            CaneData.save();

            killer.sendMessage(Text.empty()
                    .append(Icons.candy())
                    .append(Text.literal(" +" + reward).formatted(Formatting.WHITE, Formatting.BOLD))
                    .append(Text.literal("  (" + victim.getNameForScoreboard() + ")").formatted(Formatting.GRAY)), false);
        });

        // Chat: [icon] **Name** » message  (name in team colour, bold)
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            XmasTeam x = teamOf(sender);
            MutableText line = Text.empty();
            if (x != null) line.append(Icons.team(x)).append(Text.literal(" "));
            line.append(Text.literal(sender.getNameForScoreboard())
                    .formatted(x == null ? Formatting.WHITE : x.color(), Formatting.BOLD));
            line.append(Text.literal(" \u00BB ").formatted(Formatting.DARK_GRAY));
            line.append(message.getContent().copy().formatted(Formatting.WHITE));

            MinecraftServer server = sender.getEntityWorld().getServer();
            if (server == null) return true;
            server.getPlayerManager().broadcast(line, false);
            return false; // we've sent our own formatted version
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;

            // Counter above the hotbar (action bar)
            if (tickCounter % 10 == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    p.sendMessage(buildCounter(server, p), true);
                }
            }
            if (tickCounter % 20 == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) Rules.scan(p);
            }
            TabList.tick(server, tickCounter);
            Freeze.tick(server);
        });
    }

    /** Candy cane icon + count. */
    public static Text buildCounter(MinecraftServer server, ServerPlayerEntity p) {
        long canes = CaneData.get().getCanes(p.getUuid());
        return Text.empty()
                .append(Icons.candy())
                .append(Text.literal(" " + canes).formatted(Formatting.WHITE, Formatting.BOLD));
    }

    /** Small red + white burst, like candy canes breaking apart. */
    private static void deathBurst(ServerPlayerEntity victim) {
        ServerWorld w = (ServerWorld) victim.getEntityWorld();
        double x = victim.getX(), y = victim.getY() + 1.0, z = victim.getZ();
        w.spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.RED_WOOL)),
                x, y, z, 40, 0.25, 0.3, 0.25, 0.18);
        w.spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.WHITE_WOOL)),
                x, y, z, 40, 0.25, 0.3, 0.25, 0.18);
    }

    public static XmasTeam teamOf(ServerPlayerEntity p) {
        AbstractTeam t = p.getScoreboardTeam();
        if (t != null && t.getName().startsWith("xmas_")) return teamById(t.getName().substring(5));
        return null;
    }

    /** Total canes of everyone on a team. */
    public static long teamTotal(Team team) {
        long sum = 0;
        for (String name : team.getPlayerList()) {
            CaneData.Entry e = CaneData.get().findByName(name);
            if (e != null) sum += e.canes;
        }
        return sum;
    }

    public static void setupTeams(MinecraftServer server) {
        Scoreboard sb = server.getScoreboard();
        for (XmasTeam x : TEAMS) {
            Team t = sb.getTeam(x.scoreboardName());
            if (t == null) t = sb.addTeam(x.scoreboardName());
            t.setDisplayName(Text.literal(x.display()).formatted(x.color()));
            t.setColor(x.color());
            // The nametag shows only a small team icon before the (team coloured) name
            t.setPrefix(Text.empty().append(Icons.team(x)).append(Text.literal(" ")));
        }
    }

    public static XmasTeam teamById(String id) {
        for (XmasTeam x : TEAMS) if (x.id().equalsIgnoreCase(id)) return x;
        return null;
    }
}
