package net.xmas.candycanes;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/** Server rules: every pair of leggings automatically gets Swift Sneak III. */
public final class Rules {

    private Rules() {}

    /** Runs once per second for each player. */
    public static void scan(ServerPlayerEntity p) {
        MinecraftServer server = p.getEntityWorld().getServer();
        RegistryEntry<Enchantment> swift = enchantment(server, "swift_sneak");
        if (swift == null) return;

        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty() || !isLeggings(s)) continue;
            if (EnchantmentHelper.getLevel(swift, s) < 3) s.addEnchantment(swift, 3);
        }
    }

    private static boolean isLeggings(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath().endsWith("_leggings");
    }

    private static RegistryEntry<Enchantment> enchantment(MinecraftServer server, String path) {
        Registry<Enchantment> reg = server.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        return reg.getOptional(RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.ofVanilla(path))).orElse(null);
    }
}
