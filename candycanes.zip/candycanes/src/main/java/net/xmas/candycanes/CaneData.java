package net.xmas.candycanes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistent storage (config/candycanes.json). */
public class CaneData {
    public static class Entry {
        public String name = "";
        public long canes = 0;
        /** Canes awarded for killing this player. -1 = use default. */
        public int worth = -1;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("candycanes.json");

    public int defaultWorth = 20;
    /** Set to true in config/candycanes.json if the tab list comes out upside down. */
    public boolean tabOrderInverted = false;
    public Map<String, Entry> players = new HashMap<>();

    private static CaneData instance = new CaneData();

    public static CaneData get() { return instance; }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader r = Files.newBufferedReader(FILE)) {
                    CaneData d = GSON.fromJson(r, CaneData.class);
                    if (d != null) {
                        if (d.players == null) d.players = new HashMap<>();
                        instance = d;
                    }
                }
            }
        } catch (Exception e) {
            CandyCanes.LOGGER.error("Failed to load candycanes.json", e);
        }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(instance, w);
        } catch (Exception e) {
            CandyCanes.LOGGER.error("Failed to save candycanes.json", e);
        }
    }

    public Entry entry(UUID id, String name) {
        Entry e = players.computeIfAbsent(id.toString(), k -> new Entry());
        if (name != null) e.name = name;
        return e;
    }

    public Entry findByName(String name) {
        for (Entry e : players.values()) {
            if (e.name.equalsIgnoreCase(name)) return e;
        }
        return null;
    }

    public long getCanes(UUID id) {
        Entry e = players.get(id.toString());
        return e == null ? 0 : e.canes;
    }

    public int getWorth(UUID id) {
        Entry e = players.get(id.toString());
        return (e == null || e.worth < 0) ? defaultWorth : e.worth;
    }
}
