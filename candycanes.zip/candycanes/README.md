# Candy Cane Kills / Reindeer Games 2026  (Fabric, MC 1.21.11)

Build: open this folder in IntelliJ -> Gradle -> Tasks -> build -> build
Jar: build/libs/candycanes-1.0.0.jar  (put in server mods/ with Fabric API)

## Resource pack (REQUIRED for the icons)
Upload candycanes-pack.zip somewhere with a direct download link, then in server.properties:
  resource-pack=<direct link to candycanes-pack.zip>
  resource-pack-sha1=<contents of candycanes-pack.sha1.txt>
  require-resource-pack=true

## Commands (all operator-only)
/canes
/xmas setup | teams | top [count]
/xmas team join <players> <santa|tree|snowman|gift|ornament>
/xmas team leave <players>
/xmas give|take|set <players> <amount>
/xmas giveteam|taketeam <team> <amount>
/xmas worth default <amount> | worth <player> [<amount>]
/xmas freeze <players> | unfreeze <players>

Tab list upside down? set "tabOrderInverted": true in config/candycanes.json and restart.
