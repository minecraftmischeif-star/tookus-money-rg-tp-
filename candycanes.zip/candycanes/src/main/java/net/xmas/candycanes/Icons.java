package net.xmas.candycanes;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;

/** Icon glyphs from the resource pack's custom font (assets/candycanes/font/icons.json). */
public final class Icons {
    public static final int CANDY = 0xE000;

    private static final Map<String, Text> CACHE = new HashMap<>();

    private Icons() {}

    public static Text candy() {
        return glyph(CANDY, null);
    }

    public static Text team(CandyCanes.XmasTeam x) {
        return glyph(x.glyph(), x.color());
    }

    public static Text glyph(int codePoint, Formatting color) {
        String key = codePoint + ":" + (color == null ? "" : color.getName());
        return CACHE.computeIfAbsent(key, k -> {
            JsonObject o = new JsonObject();
            o.addProperty("text", String.valueOf((char) codePoint));
            o.addProperty("font", "candycanes:icons");
            if (color != null) o.addProperty("color", color.getName());
            return TextCodecs.CODEC.parse(JsonOps.INSTANCE, o).result().orElseGet(() -> Text.literal("?"));
        });
    }
}
