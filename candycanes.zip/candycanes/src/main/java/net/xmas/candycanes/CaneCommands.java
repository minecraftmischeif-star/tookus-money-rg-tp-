package net.xmas.candycanes;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Collection;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class CaneCommands {

    private static final SuggestionProvider<ServerCommandSource> TEAM_SUGGEST = (ctx, builder) ->
            CommandSource.suggestMatching(CandyCanes.TEAMS.stream().map(CandyCanes.XmasTeam::id), builder);

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        // Operators only: /canes
        d.register(literal("canes")
                .requires(CommandManager.requirePermissionLevel(CommandManager.GAMEMASTERS_CHECK))
                .executes(ctx -> {
            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
            ctx.getSource().sendFeedback(() -> CandyCanes.buildCounter(ctx.getSource().getServer(), p), false);
            return 1;
        }));

        // Admin: /xmas ...
        LiteralArgumentBuilder<ServerCommandSource> xmas = literal("xmas")
                .requires(CommandManager.requirePermissionLevel(CommandManager.GAMEMASTERS_CHECK));

        // /xmas setup
        xmas.then(literal("setup").executes(ctx -> {
            CandyCanes.setupTeams(ctx.getSource().getServer());
            ok(ctx.getSource(), "Christmas teams created/refreshed.");
            return 1;
        }));

        // /xmas teams
        xmas.then(literal("teams").executes(ctx -> {
            Scoreboard sb = ctx.getSource().getServer().getScoreboard();
            for (CandyCanes.XmasTeam x : CandyCanes.TEAMS) {
                Team t = sb.getTeam(x.scoreboardName());
                int members = t == null ? 0 : t.getPlayerList().size();
                long total = t == null ? 0 : CandyCanes.teamTotal(t);
                ctx.getSource().sendFeedback(() -> Text.literal(x.id() + " - " + x.display()
                        + " (" + members + " members, " + total + " canes)").formatted(x.color()), false);
            }
            return 1;
        }));

        // /xmas team join <players> <team> | /xmas team leave <players>
        xmas.then(literal("team")
                .then(literal("join")
                        .then(argument("targets", EntityArgumentType.players())
                                .then(argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST)
                                        .executes(ctx -> {
                                            Collection<ServerPlayerEntity> targets = EntityArgumentType.getPlayers(ctx, "targets");
                                            CandyCanes.XmasTeam x = CandyCanes.teamById(StringArgumentType.getString(ctx, "team"));
                                            if (x == null) return fail(ctx.getSource(), "Unknown team.");
                                            Scoreboard sb = ctx.getSource().getServer().getScoreboard();
                                            CandyCanes.setupTeams(ctx.getSource().getServer());
                                            Team team = sb.getTeam(x.scoreboardName());
                                            for (ServerPlayerEntity p : targets) {
                                                String n = p.getNameForScoreboard();
                                                if (sb.getScoreHolderTeam(n) != null) sb.removeScoreHolderFromTeam(n, sb.getScoreHolderTeam(n));
                                                sb.addScoreHolderToTeam(n, team);
                                            }
                                            TabList.refresh(ctx.getSource().getServer(), targets);
                                            ok(ctx.getSource(), "Added " + targets.size() + " player(s) to " + x.display() + ".");
                                            return targets.size();
                                        }))))
                .then(literal("leave")
                        .then(argument("targets", EntityArgumentType.players()).executes(ctx -> {
                            Collection<ServerPlayerEntity> targets = EntityArgumentType.getPlayers(ctx, "targets");
                            Scoreboard sb = ctx.getSource().getServer().getScoreboard();
                            for (ServerPlayerEntity p : targets) {
                                String n = p.getNameForScoreboard();
                                Team cur = sb.getScoreHolderTeam(n);
                                if (cur != null) sb.removeScoreHolderFromTeam(n, cur);
                            }
                            TabList.refresh(ctx.getSource().getServer(), targets);
                            ok(ctx.getSource(), "Removed " + targets.size() + " player(s) from their teams.");
                            return targets.size();
                        }))));

        // Individuals: give / take / set
        xmas.then(literal("give").then(argument("targets", EntityArgumentType.players())
                .then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx ->
                        modifyPlayers(ctx.getSource(), EntityArgumentType.getPlayers(ctx, "targets"),
                                IntegerArgumentType.getInteger(ctx, "amount"), Mode.GIVE)))));

        xmas.then(literal("take").then(argument("targets", EntityArgumentType.players())
                .then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx ->
                        modifyPlayers(ctx.getSource(), EntityArgumentType.getPlayers(ctx, "targets"),
                                IntegerArgumentType.getInteger(ctx, "amount"), Mode.TAKE)))));

        xmas.then(literal("set").then(argument("targets", EntityArgumentType.players())
                .then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx ->
                        modifyPlayers(ctx.getSource(), EntityArgumentType.getPlayers(ctx, "targets"),
                                IntegerArgumentType.getInteger(ctx, "amount"), Mode.SET)))));

        // Whole teams: givet / taket (applies amount to EVERY member)
        xmas.then(literal("giveteam").then(argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST)
                .then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx ->
                        modifyTeam(ctx.getSource(), StringArgumentType.getString(ctx, "team"),
                                IntegerArgumentType.getInteger(ctx, "amount"), Mode.GIVE)))));

        xmas.then(literal("taketeam").then(argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST)
                .then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx ->
                        modifyTeam(ctx.getSource(), StringArgumentType.getString(ctx, "team"),
                                IntegerArgumentType.getInteger(ctx, "amount"), Mode.TAKE)))));

        // Kill worth: /xmas worth default <n> | /xmas worth <player> [<n>]
        xmas.then(literal("worth")
                .then(literal("default").then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx -> {
                    int a = IntegerArgumentType.getInteger(ctx, "amount");
                    CaneData.get().defaultWorth = a;
                    CaneData.save();
                    ok(ctx.getSource(), "Default kill worth is now " + a + " canes.");
                    return 1;
                })))
                .then(argument("player", EntityArgumentType.player())
                        .executes(ctx -> {
                            ServerPlayerEntity p = EntityArgumentType.getPlayer(ctx, "player");
                            ok(ctx.getSource(), p.getNameForScoreboard() + " is worth "
                                    + CaneData.get().getWorth(p.getUuid()) + " canes.");
                            return 1;
                        })
                        .then(argument("amount", IntegerArgumentType.integer(0)).executes(ctx -> {
                            ServerPlayerEntity p = EntityArgumentType.getPlayer(ctx, "player");
                            int a = IntegerArgumentType.getInteger(ctx, "amount");
                            CaneData.get().entry(p.getUuid(), p.getNameForScoreboard()).worth = a;
                            CaneData.save();
                            ok(ctx.getSource(), p.getNameForScoreboard() + " is now worth " + a + " canes per kill.");
                            return 1;
                        }))));

        // /xmas freeze <players> | /xmas unfreeze <players>
        xmas.then(literal("freeze").then(argument("targets", EntityArgumentType.players()).executes(ctx -> {
            Collection<ServerPlayerEntity> targets = EntityArgumentType.getPlayers(ctx, "targets");
            for (ServerPlayerEntity p : targets) {
                Freeze.freeze(p);
                p.sendMessage(Text.literal("You have been frozen.").formatted(Formatting.AQUA), false);
            }
            ok(ctx.getSource(), "Froze " + targets.size() + " player(s).");
            return targets.size();
        })));
        xmas.then(literal("unfreeze").then(argument("targets", EntityArgumentType.players()).executes(ctx -> {
            Collection<ServerPlayerEntity> targets = EntityArgumentType.getPlayers(ctx, "targets");
            for (ServerPlayerEntity p : targets) {
                Freeze.unfreeze(p);
                p.sendMessage(Text.literal("You have been unfrozen.").formatted(Formatting.GREEN), false);
            }
            ok(ctx.getSource(), "Unfroze " + targets.size() + " player(s).");
            return targets.size();
        })));

        // /xmas top [count]  (operators only, output goes only to the sender)
        xmas.then(literal("top")
                .executes(ctx -> leaderboard(ctx.getSource(), 10))
                .then(argument("count", IntegerArgumentType.integer(1, 50)).executes(ctx ->
                        leaderboard(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count")))));

        d.register(xmas);
    }

    private static int leaderboard(ServerCommandSource src, int count) {
        CaneData data = CaneData.get();

        java.util.List<CaneData.Entry> sorted = new java.util.ArrayList<>(data.players.values());
        sorted.sort((a, b) -> Long.compare(b.canes, a.canes));

        src.sendFeedback(() -> Text.literal("=== Candy Cane Leaderboard ===").formatted(Formatting.RED, Formatting.BOLD), false);
        int shown = Math.min(count, sorted.size());
        if (shown == 0) {
            src.sendFeedback(() -> Text.literal("No players yet.").formatted(Formatting.GRAY), false);
        }
        for (int i = 0; i < shown; i++) {
            CaneData.Entry e = sorted.get(i);
            int rank = i + 1;
            src.sendFeedback(() -> Text.literal("#" + rank + " ").formatted(Formatting.GOLD)
                    .append(Text.literal(e.name).formatted(Formatting.WHITE))
                    .append(Text.literal(" - " + e.canes).formatted(Formatting.GREEN)), false);
        }

        src.sendFeedback(() -> Text.literal("--- Teams ---").formatted(Formatting.GREEN, Formatting.BOLD), false);
        Scoreboard sb = src.getServer().getScoreboard();
        java.util.List<java.util.Map.Entry<CandyCanes.XmasTeam, Long>> teams = new java.util.ArrayList<>();
        for (CandyCanes.XmasTeam x : CandyCanes.TEAMS) {
            Team t = sb.getTeam(x.scoreboardName());
            teams.add(java.util.Map.entry(x, t == null ? 0L : CandyCanes.teamTotal(t)));
        }
        teams.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        for (java.util.Map.Entry<CandyCanes.XmasTeam, Long> te : teams) {
            src.sendFeedback(() -> Text.literal(te.getKey().display() + " - " + te.getValue())
                    .formatted(te.getKey().color()), false);
        }
        return shown;
    }

    private enum Mode { GIVE, TAKE, SET }

    private static long apply(long current, int amount, Mode mode) {
        return switch (mode) {
            case GIVE -> current + amount;
            case TAKE -> Math.max(0, current - amount);
            case SET -> amount;
        };
    }

    private static int modifyPlayers(ServerCommandSource src, Collection<ServerPlayerEntity> targets, int amount, Mode mode) {
        CaneData data = CaneData.get();
        for (ServerPlayerEntity p : targets) {
            CaneData.Entry e = data.entry(p.getUuid(), p.getNameForScoreboard());
            e.canes = apply(e.canes, amount, mode);
        }
        CaneData.save();
        ok(src, mode + " " + amount + " canes -> " + targets.size() + " player(s).");
        return targets.size();
    }

    private static int modifyTeam(ServerCommandSource src, String teamId, int amount, Mode mode) {
        CandyCanes.XmasTeam x = CandyCanes.teamById(teamId);
        if (x == null) return fail(src, "Unknown team. Use: santa, tree, snowman, gift, ornament.");
        MinecraftServer server = src.getServer();
        Team team = server.getScoreboard().getTeam(x.scoreboardName());
        if (team == null) return fail(src, "Teams not set up yet. Run /xmas setup.");

        int count = 0;
        for (String name : team.getPlayerList()) {
            CaneData.Entry e = CaneData.get().findByName(name);
            if (e == null) continue; // never joined with the mod installed
            e.canes = apply(e.canes, amount, mode);
            count++;
        }
        CaneData.save();
        ok(src, mode + " " + amount + " canes to each of " + count + " member(s) of " + x.display() + ".");
        return count;
    }

    private static void ok(ServerCommandSource src, String msg) {
        src.sendFeedback(() -> Text.literal(msg).formatted(Formatting.GREEN), true);
    }

    private static int fail(ServerCommandSource src, String msg) {
        src.sendError(Text.literal(msg));
        return 0;
    }
}
