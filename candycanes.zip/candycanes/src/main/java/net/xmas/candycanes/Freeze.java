package net.xmas.candycanes;

import net.fabricmc.fabric.api.event.player.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Frozen players can look around but cannot move, attack, break, place or use items. */
public final class Freeze {
    private static final Map<UUID, double[]> FROZEN = new HashMap<>();

    private Freeze() {}

    public static boolean isFrozen(UUID id) {
        return FROZEN.containsKey(id);
    }

    public static void freeze(ServerPlayerEntity p) {
        FROZEN.put(p.getUuid(), new double[]{p.getX(), p.getY(), p.getZ()});
        p.setNoGravity(true);
    }

    public static void unfreeze(ServerPlayerEntity p) {
        FROZEN.remove(p.getUuid());
        p.setNoGravity(false);
    }

    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) ->
                isFrozen(player.getUuid()) ? ActionResult.FAIL : ActionResult.PASS);
        UseBlockCallback.EVENT.register((player, world, hand, hit) ->
                isFrozen(player.getUuid()) ? ActionResult.FAIL : ActionResult.PASS);
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                isFrozen(player.getUuid()) ? ActionResult.FAIL : ActionResult.PASS);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                isFrozen(player.getUuid()) ? ActionResult.FAIL : ActionResult.PASS);
        AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) ->
                isFrozen(player.getUuid()) ? ActionResult.FAIL : ActionResult.PASS);
    }

    public static void tick(MinecraftServer server) {
        if (FROZEN.isEmpty()) return;
        for (Map.Entry<UUID, double[]> e : FROZEN.entrySet()) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            if (p == null) continue;
            double[] f = e.getValue();
            double dx = p.getX() - f[0], dy = p.getY() - f[1], dz = p.getZ() - f[2];
            if (dx * dx + dy * dy + dz * dz > 1.0E-4) {
                // Snap position back but keep the player's own look direction
                p.networkHandler.requestTeleport(f[0], f[1], f[2], p.getYaw(), p.getPitch());
            }
        }
    }
}
