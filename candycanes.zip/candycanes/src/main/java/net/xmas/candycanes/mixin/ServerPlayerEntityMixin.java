package net.xmas.candycanes.mixin;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.xmas.candycanes.TabList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Controls how each player appears (and where they sit) in everybody's tab list. */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(method = "getPlayerListName", at = @At("HEAD"), cancellable = true)
    private void candycanes$listName(CallbackInfoReturnable<Text> cir) {
        Text t = TabList.nameText((ServerPlayerEntity) (Object) this);
        if (t != null) cir.setReturnValue(t);
    }

    @Inject(method = "getPlayerListOrder", at = @At("HEAD"), cancellable = true)
    private void candycanes$listOrder(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(TabList.order((ServerPlayerEntity) (Object) this));
    }
}
